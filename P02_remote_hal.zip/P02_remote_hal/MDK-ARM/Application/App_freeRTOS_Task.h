#ifndef __APP_FREERTOS_TASK__
#define __APP_FREERTOS_TASK__

#include "FreeRTOS.h"
#include "task.h"
#include "Com_debug.h"
#include "Int_IP5305T.h"
#include "Int_SI24R1.h"
/**
 * @brief ����freeRTOS����ϵͳ
 * 
 */
void App_freeRTOS_start(void);

#endif // __APP_FREERTOS_TASK__
