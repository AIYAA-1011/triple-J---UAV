#ifndef __INF_OLED__
#define __INF_OLED__

#include "main.h"
#include "gpio.h"

#define OLED_CS_GPIO GPIOA
#define OLED_CS_Pin GPIO_PIN_4

#define OLED_DC_GPIO GPIOB
#define OLED_DC_Pin GPIO_PIN_1

#define OLED_RST_GPIO GPIOB
#define OLED_RST_Pin GPIO_PIN_0

#define OLED_SDIN_GPIO GPIOA
#define OLED_SDIN_Pin GPIO_PIN_7

#define OLED_SCLK_GPIO GPIOA
#define OLED_SCLK_Pin GPIO_PIN_5

//-----------------OLED�˿ڶ���----------------
#define OLED_CS_Clr() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET) // CS
#define OLED_CS_Set() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)   // CS

#define OLED_DC_Clr() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET) // DC
#define OLED_DC_Set() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET)   // DC

#define OLED_RST_Clr() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET) // RST
#define OLED_RST_Set() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET)   // RST

#define OLED_SDIN_Clr() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET) // SDA
#define OLED_SDIN_Set() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET)   // SDA

#define OLED_SCLK_Clr() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET) // SCL
#define OLED_SCLK_Set() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET)   // SCL

#define OLED_CMD 0  // д����
#define OLED_DATA 1 // д����
// OLED�����ú���
void OLED_Init(void);
void OLED_WR_Byte(uint8_t dat, uint8_t cmd);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Refresh_Gram(void);
void OLED_Clear(void);
void OLED_DrawPoint(uint8_t x, uint8_t y, uint8_t t);
void OLED_ShowChar(uint8_t x, uint8_t y, uint8_t chr, uint8_t size, uint8_t mode);
void OLED_ShowString(uint8_t x, uint8_t y, const uint8_t *p, uint8_t size, uint8_t mode);
void OLED_ShowCH(uint8_t x, uint8_t y, uint8_t chr, uint8_t size, uint8_t mode);
void OLED_Show_CH(uint8_t x, uint8_t y, uint8_t chr, uint8_t size, uint8_t mode);

#endif // __INF_OLED__
