#ifndef __INT_IP5305T__
#define __INT_IP5305T__

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"

void Int_IP5305T_start(void);

#endif
