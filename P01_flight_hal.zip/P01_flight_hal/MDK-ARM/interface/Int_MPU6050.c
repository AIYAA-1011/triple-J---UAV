#include "Int_MPU6050.h"


/**
 * @brief MPU6050读取寄存器函数
 * 
 * @param reg 寄存器地址
 * @param data 读取到的数据
 */
void Int_MPU6050_write_reg(uint8_t reg, uint8_t data){
    //HAL库有固定的I2C读写函数，直接调用即可
    ////1.句柄(hi2c1)2.从设备地址(0x68)3.寄存器地址 neg4.寄存器地址的位数5.写入的数据地址6.写入的字节个数7.超时时间
    HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR_WRITE, reg, I2C_MEMADD_SIZE_8BIT, &data, 1, 1000);
}

void Int_MPU6050_read_reg(uint8_t reg, uint8_t *data){
    //HAL库有固定的I2C读写函数，直接调用即可
    ////1.句柄(hi2c1)2.从设备地址(0x68)3.寄存器地址 neg4.寄存器地址的位数5.读取的数据地址6.读取的字节个数7.超时时间
    HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR_READ, reg, I2C_MEMADD_SIZE_8BIT, data, 1, 1000);
}


/*
MPU6050初始化函数声明
*/


void MPU6050_Init(void){
     //重启芯片，重置所有寄存器的值 =>写电源管理寄存器1 =>DEVICE_RESET=1
    Int_MPU6050_write_reg(0x6B, 0x80);
    uint8_t data = 0;
    //重置完成之后 0x6B寄存器的值是0x40表示当前为低功耗式
    while(data != 0x40)
    {
        Int_MPU6050_read_reg(0x6B, &data);
    }
    //唤醒MPU6050，进入正常状态
    Int_MPU6050_write_reg(0x6B, 0x00);

    //选择合适的量程=>在够用的范围内精度越高越好
    //2.选择合适的量程=>在够用的范围内选择的越小越好=>精度高
    //2.1填写角速度量程为±2000°/s
    Int_MPU6050_Write_Reg(0x1B,3 <<3);
    //2.2填写加速度量程为±2g
    Int_MPU6050_Write_Reg(0x1C,0x00);
    // 3.关闭中断使能因为用不到中断
    Int_MPU6050_Write_Reg(0x38,0x00);
    //4.用户配置寄存器不使用FIFO队列 不使用扩展的I2C
    Int_MPU6050_Write_Reg(0x6A,0x00);
    //5.设置采样频率=>陀螺仪监控三轴加速度和三轴角速度度=>默认频率1000HZ=>1ms读取一次
    //基本逻辑=>采样率必须大于后续数据的使用频率 否则失真=>香农定理采样率>=2倍使用频率
    Int_MPU6050_write_reg(0x19,0x01);
}