#ifndef INT_MPU6050_
#define INT_MPU6050_

// MPU6050 interface functions
#include "i2c.h"

//从设备地址
#define MPU6050_ADDR 0x68
//读写地址
#define MPU6050_ADDR_WRITE 0xD0
#define MPU6050_ADDR_READ 0xD1
/*
MPU6050初始化函数声明
*/

void MPU6050_Init(void);

#endif // INT_MPU6050_